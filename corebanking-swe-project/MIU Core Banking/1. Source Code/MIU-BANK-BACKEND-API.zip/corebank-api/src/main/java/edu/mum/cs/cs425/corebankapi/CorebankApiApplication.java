package edu.mum.cs.cs425.corebankapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorebankApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorebankApiApplication.class, args);
	}

}
