package edu.mum.cs.cs425.corebankapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorebankApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
