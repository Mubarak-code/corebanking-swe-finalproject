
import { Injectable, Injector } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class MyHttpInterceptor implements HttpInterceptor {
    constructor(private injector: Injector) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

      console.log("RES BODY",req.body)
      if(req.method == "GET"){
        console.log("bekiiiiiiiiiiiiiiiii",req)
      }
      // console.log(req)
        // var authService: AuthService = this.injector.get(AuthService);

        // var sharedService: SharedServiceService = this.injector.get(SharedServiceService);

        // if (req.url == 'http://localhost:5566/infos') {
        //     return next.handle(req);
        // }
        // var access_token = authService.getAccessToken() ? authService.getAccessToken() : '';
        // sharedService.webSocket();
        // Clone the request to add the new header.

        if (req.url == 'http://localhost:5566/infos') {
            return next.handle(req)
        }
        // const authReq = req.clone(
        //     {
        //         headers: req.headers.set('Authorization', 'Bearer ' + access_token)
        //     }
        // );
        console.log("Sending request with new header now ...");

        //send the newly created request
        return next.handle(req);
            // .catch((error) => {
            //     return Observable.throw(error);
            // }) as any;
    }
}
