
import { PageNotFoundComponent } from "./components/page-not-found/page-not-found.component";
import { ShellComponent } from "./components/shell/shell.component";
import { DashboardComponent } from "./components/dashboard/dashboard.component";
import { AppComponent } from "./app.component";
import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AdminComponent } from "./Admin/Admin.component";
import {CreateUserComponent} from "./components/teller/create-customer/create-user.component";

const routes: Routes = [
  {
    path: "login",
    component: ShellComponent
  },
  {
    path: "user-account",
    loadChildren: () =>
    import("./components/user-account/user-account.module").then(
      u => u.UserAccountModule
    )
},
  {
    path: '', component: AdminComponent,

    children: [
      {
        path: "",
        redirectTo: "login",
        pathMatch: "full"
      },
      {
        path: "shell",
        component: ShellComponent
      },

      {
        path: "dashboard",
        loadChildren: () =>
          import("./components/dashboard/dashboard.module").then(
            m => m.DashboardModule
          )
      },
      {
        path: "student",
        loadChildren: () =>
          import("./components/student/student.module").then(
            m => m.StudentModule
          )
      },
      {
        path: "product",
        loadChildren: () =>
          import("./components/product/product.module").then(
            m => m.ProductModule
          )
      },
      {
        path: "transaction",
        loadChildren: () =>
          import("./components//Transaction//Transaction.module").then(
            t => t.TransactionModule
          )
      },
      {
        path:"loanapplication",
        loadChildren:()=> import("./components/loan-application/loan-application.module").then(l =>l.LoanApplicationModule)
      },
      {
        path:"admin",
        loadChildren:()=> import("./components/Admin-management/Admin-management.module").then(a =>a.AdminManagementModule)

      },
      {
        path:"teller",
        loadChildren:()=> import("./components/teller/teller.module").then(l =>l.TellerModule)
      },
      {
        path: "**",
        component: PageNotFoundComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
