
import { StudentService } from './service/student.service';
import { Component, OnInit } from '@angular/core';
import {map, filter, tap} from 'rxjs/operators';
@Component({
  selector: 'app-root',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'eregistrar';
  students:any[];

  constructor(private studentService:StudentService){}
  ngOnInit(): void {

  }



}
