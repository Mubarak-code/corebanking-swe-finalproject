// import { RouterModule } from '@angular/router';
import { ShellComponent } from './components/shell/shell.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentService } from './service/student.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HeaderComponent } from './components/layout/header/header.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { AdminComponent } from './Admin/Admin.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { FormsModule } from '@angular/forms';
import { SideBarComponent } from './components/layout/side-bar/side-bar.component';
import { CommonModule } from '@angular/common';
import { CreateUserComponent } from './components/teller/create-customer/create-user.component';
import { SendPaycheckComponent } from './components/teller/send-paycheck/send-paycheck.component';
import {MenubarModule} from 'primeng/menubar';
import { ListCustomerComponent } from './components/teller/list-customer/list-customer.component';
import { MyHttpInterceptor } from './Admin/myinterceptor';

@NgModule({
   declarations: [
      AppComponent,
      HeaderComponent,
      FooterComponent,
      AdminComponent,
      PageNotFoundComponent,
      SideBarComponent,
      ShellComponent
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      HttpClientModule,
      FormsModule,
      CommonModule,
      MenubarModule,
      // RouterModule
   ],
   providers: [
      StudentService,
      {
        provide: HTTP_INTERCEPTORS,
        useClass: MyHttpInterceptor,
        multi: true,

      },
   ],
   bootstrap: [
      AppComponent
   ],

})
export class AppModule { }
