import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Admin-management',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./Admin-management.component.css']
})
export class AdminManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
