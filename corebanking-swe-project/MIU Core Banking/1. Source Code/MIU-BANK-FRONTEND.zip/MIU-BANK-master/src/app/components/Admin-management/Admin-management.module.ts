import { AddInterestRateComponent } from "./interest-rate/add-interest-rate/add-interest-rate.component";
import { AddUserComponent } from "./user/add-user/add-user.component";
import { RouterModule } from "@angular/router";
import { FormsModule } from "@angular/forms";
import { InterestRateComponent } from "./interest-rate/interest-rate.component";
import { UserComponent } from "./user/user.component";
import { Routes } from "@angular/router";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AdminManagementComponent } from "./Admin-management.component";
const route: Routes = [
  {
    path: "user",
    loadChildren: () => import("./user/user.module").then(u => u.UserModule)
  },

  {
    path: "interest-rate",
    children: [
      {
        path: "",
        component: InterestRateComponent
      }
      ,
      {
        path: "add-interest-rate",
        component: AddInterestRateComponent
      }
    ]
  }
];
@NgModule({
  imports: [CommonModule, FormsModule, RouterModule.forChild(route)],
  declarations: [AdminManagementComponent, InterestRateComponent]
})
export class AdminManagementModule {}
