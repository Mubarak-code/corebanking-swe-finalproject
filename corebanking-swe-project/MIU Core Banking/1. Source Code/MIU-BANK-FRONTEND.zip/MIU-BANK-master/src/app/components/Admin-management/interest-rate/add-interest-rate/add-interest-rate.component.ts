import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-interest-rate',
  templateUrl: './add-interest-rate.component.html',
  styleUrls: ['./add-interest-rate.component.css']
})
export class AddInterestRateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
