import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interest-rate',
  templateUrl: './interest-rate.component.html',
  styleUrls: ['./interest-rate.component.css']
})
export class InterestRateComponent implements OnInit {

  interestRate:any={}
  interestRates:[];
  show: boolean = false;
  constructor() { }

  ngOnInit() {
  }

  create(){

  }
  showForm(value:any){
    console.log("value",value)
    if(value ){
      this.show = true;
    }else{
      this.interestRate={};
      this.show = true;
    }
  }
  hideForm(){
  this.show = false;
  }
}
