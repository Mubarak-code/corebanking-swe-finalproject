import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InterestRateComponent } from './interest-rate.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [InterestRateComponent]
})
export class InterestRateModule { }
