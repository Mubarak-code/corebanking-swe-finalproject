import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit() {
  }
  previousState() {
    window.history.back();
  }

  create(){
   this.previousState;
  }
}
