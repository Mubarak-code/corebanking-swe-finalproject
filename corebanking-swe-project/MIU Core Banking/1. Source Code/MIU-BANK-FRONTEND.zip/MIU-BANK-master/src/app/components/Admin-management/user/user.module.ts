import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Routes } from '@angular/router';
import { Router } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserComponent } from './user.component';
import { AddUserComponent } from './add-user/add-user.component';

const userRoutes :Routes=[
  {
    path: "",
    component: UserComponent
  },
      {
        path:'add',
        component:AddUserComponent
      }
]
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(userRoutes)
  ],
  declarations: [UserComponent,AddUserComponent]
})
export class UserModule { }
