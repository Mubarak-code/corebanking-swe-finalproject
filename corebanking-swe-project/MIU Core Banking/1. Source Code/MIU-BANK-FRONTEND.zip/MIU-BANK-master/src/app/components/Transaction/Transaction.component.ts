import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Transaction',
  templateUrl: './Transaction.component.html',
  styleUrls: ['./Transaction.component.css']
})
export class TransactionComponent implements OnInit {

  transactions:[];
  constructor() { }

  ngOnInit() {
  }

}
