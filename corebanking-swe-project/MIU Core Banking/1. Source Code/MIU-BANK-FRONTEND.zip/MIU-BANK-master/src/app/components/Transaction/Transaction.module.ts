import { AddTransactionComponent } from './add-transaction/add-transaction.component';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransactionComponent } from './Transaction.component';
import { FormsModule } from '@angular/forms';

export const transactionRoutes:Routes =[
  {
    path:'',
    component:TransactionComponent
  },
  {
    path:'add',
    component:AddTransactionComponent
  }
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(transactionRoutes),
    FormsModule,

  ],
  declarations: [TransactionComponent,AddTransactionComponent]
})
export class TransactionModule { }
