import { Router } from '@angular/router';
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-add-transaction",
  templateUrl: "./add-transaction.component.html",
  styleUrls: ["./add-transaction.component.css"]
})
export class AddTransactionComponent implements OnInit {
  transaction: any = {};

  transactionType: any = [
    { name: "TRANSFER" },
    { name: "DEPOSIT" },
    { name: "WITHDRAW" }
  ];

  accountType: any = [{ name: "SAVING" }, { name: "CHECKING" }];

  constructor(private route:Router) {}

  ngOnInit() {}

  create() {
    this.previousState();
    // this.route.navigate(['/transaction']);
  }

  previousState() {
    window.history.back();
  }
}
