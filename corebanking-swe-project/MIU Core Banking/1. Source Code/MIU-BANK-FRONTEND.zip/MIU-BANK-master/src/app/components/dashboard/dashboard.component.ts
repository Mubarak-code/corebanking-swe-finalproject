import { Component, OnInit } from '@angular/core';
import {TransactionService} from "../../service/transaction.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  allTransactions: any[];
  customerTransaction:any[];
  customer: any;
  userType: number;

  constructor(private transactionService: TransactionService) { }

  ngOnInit() {
    this.customer =  JSON.parse(localStorage.getItem("user"));
    console.log("tihis. customer",this.customer)
    this.userType = this.customer.userType.userTypeId
    this.getAllTransactions();
    this.getCustomerTransaction();
  }

  getAllTransactions(){
    this.transactionService.getAllTransaction().subscribe(
      res=>{
        this.allTransactions = res.data;
      }
    )
  }
  getCustomerTransaction(){
    this.transactionService.getCustomerTransaction(1).subscribe(
      res=>{
        this.customerTransaction = res.data;
      }
    )
  }

}
