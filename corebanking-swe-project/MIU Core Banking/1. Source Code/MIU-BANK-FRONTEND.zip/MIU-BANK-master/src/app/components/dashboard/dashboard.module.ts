import { DefaultComponent } from './default/default.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { Routes, RouterModule } from '@angular/router';
import {ButtonModule} from 'primeng/button';
export const dashboardRoutes: Routes = [
  {
    path: '',
    component: DashboardComponent,
  },
  {
    path: 'd',
    component: DefaultComponent,
  }

]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(dashboardRoutes),
    ButtonModule
  ],
  declarations: [DashboardComponent,DefaultComponent]
})
export class DashboardModule { }
