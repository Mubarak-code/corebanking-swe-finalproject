import { LoanApplicationService } from './../../../service/loanApplicationService';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-add-loan-application',
  templateUrl: './add-loan-application.component.html',
  styleUrls: ['./add-loan-application.component.css']
})
export class AddLoanApplicationComponent implements OnInit {

  ammountToPay:number=0;
  ammount:number=0;
  yearlength:number=0;

  loanApplication:any={};
   sechedules:any[]=[];
  months: number;
  ammountx:any
  rate: any;
  customerName: any;
  prinicpal: number;
  outstandingBalance: number;
  interestRate: number;
  accountBalance: any;
  constructor(private route:Router,private loanService:LoanApplicationService,private router:ActivatedRoute) { }

  ngOnInit() {
    this.router.data.subscribe(res => {
      console.log("res",res)
      this.customerName =  res.customer.data[0].customerName;
     this.loanApplication.customerId= res.customer.data[0].customerId;
     console.log("custmomerid",res.customer.data[0].customerId)
     res.customer.data[0].account.forEach(element => {
       if(element.accountType.accountTypeId == 1){
        this.accountBalance = element.balance
       }
     });
    //  =  res.customer.data[0].account[0].balance;

     console.log("this.ac",this.accountBalance)
    });
    this.loanService.getRates().subscribe(res => {
      this.rate = res.data[0];
     this.loanApplication.interestRate = this.rate.loanRate;
      console.log("rate",this.rate)
    })
  }


  create(){
    this.loanApplication.schedules = this.sechedules;

    this.loanService.creatLoan(this.loanApplication).subscribe(res => {
      alert("Operation Successfull!");
      this.route.navigate(["/loanapplication"]);


    },err=>{
      console.log(err);
    })

  }

  ammountChange(value:any){
    if(value > 0){
      console.log("ammountChange",value)
      this.sechedules=[];

      this.ammount = value;
      this.outstandingBalance = this.ammount;
      this.ammountToPay = 0;
      // let months = this.yearlength *12;
      // this.months = this.months;
       if(value > 12 && this.months>0){

        // this.prinicpal = this.ammount/(this.months);
        console.log("this.prinicpal",this.prinicpal)
        // this.generateSchedules();
       }
       this.loanApplication.loanAmount = value;
    }

  }

  lengthChange(value:number){

    // if(value){
    //   console.log("valuevvvv",value)
    //   this.loanApplication.length = value;
    //   this.sechedules=[];
    //   // this.months = value*12;
    //   var months = value;
    //   console.log("this.months",months)
    //   this.months = months;
    //   console.log("in len",this.ammount)
    //   this.prinicpal = this.outstandingBalance / this.months
    //   if(value>0 && this.ammount > 12){
    //     // this.prinicpal = this.ammount/(months);
    //     console.log("this.prinicpal ",this.prinicpal )
    //     this.generateSchedules(  this.prinicpal);
    //   }else{
    //     this.prinicpal = 0;
    //   }
    //   console.log("schedules",this.sechedules)
    // }

  }

  generate(ammount ,length){
    this.loanApplication.length = length;
    this.sechedules=[];
    console.log(ammount,length)
    this.months = length;
    this.outstandingBalance = ammount;
    this.prinicpal = this.outstandingBalance / this.months;
    this.interestRate = this.months /12;
    this.generateSchedules();
  }
  generateSchedules(){
      var m = moment();
      m = m.months(moment().month());
      for (var i = 0; i < this.months ; i++) {
        let interest = this.prinicpal * this.interestRate
        this.outstandingBalance = this.outstandingBalance - this.prinicpal;
        if(this.outstandingBalance < 0)
          this.outstandingBalance = this.outstandingBalance * -1;
        this.sechedules.push({
          outstandingBalance: this.outstandingBalance.toFixed(2),
          paymentDate:m.months(i).format('YYYY-MM-DD'),
          principal:this.prinicpal.toFixed(2)  ,
          interest:interest.toFixed(2)
        })
        m = m.months(moment().month() + 1);
      }
  }

}
