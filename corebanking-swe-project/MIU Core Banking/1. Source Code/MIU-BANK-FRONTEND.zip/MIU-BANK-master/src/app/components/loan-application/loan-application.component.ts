import { Router } from "@angular/router";
import { LoanApplicationService } from "./../../service/loanApplicationService";
import { Component, OnInit } from "@angular/core";
import { TransactionService } from "src/app/service/transaction.service";

@Component({
  selector: "app-loan-application",
  templateUrl: "./loan-application.component.html",
  styleUrls: ["./loan-application.component.css"]
})
export class LoanApplicationComponent implements OnInit {
  loanApplications: any[];
  customerLoanApplication: any [];
  rate: any;
  totalSchedule: number;
  user: any={};
  customerId: any;
  userType: any;
  constructor(
    private route: Router,
    private loanapplicationService: LoanApplicationService,
    private transactionService: TransactionService
  ) {}

  ngOnInit() {
    this.user =  JSON.parse(localStorage.getItem("user"));
    // this.customerId = this.user.customer.customerId;
    // this.getAllLoanApplictions();
    // this.getLoanApplicationsByCustomerId();
    this.userType = this.user.userType.userTypeId;
    this.user =  JSON.parse(localStorage.getItem("customer"));

    // if(this.user.userType.userTypeId == 3){
    //   this.loanapplicationService.getLoanApplicationsById(this.user.customer.customerId).subscribe(res => {
    //     this.loanApplications = res.data;
    //   });
    // }else {
       this.getAllLoanApplictions();
    // }

  }
  getAllLoanApplictions() {
    this.loanapplicationService.getLoanApplications().subscribe(res => {
      this.loanApplications = res.data;
    });
  }
  // getLoanApplicationsByCustomerId(){
  //   console.log("fasdddddddddddddddd",this.customerId);
  //   this.loanapplicationService.getLoanApplicationsByCustomerId(this.customerId).subscribe(
  //     res=>{
  //       this.customerLoanApplication = res.data;
  //     }
  //   )
  // }
  payLoan(appNum) {
    this.transactionService.payLoan(appNum).subscribe(res => {
      this.getAllLoanApplictions();
      alert("Successfully paid");
    });
  }

  navigateToDetail(id) {
    console.log("iddd", id);
    this.route.navigate(["loanapplication/detail/" + id]);
  }
}
