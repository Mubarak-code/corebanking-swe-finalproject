import { customerResolver } from './../teller/teller.module';
import { LoanApplicationService } from './../../service/loanApplicationService';
import { AddLoanApplicationComponent } from './add-loan-application/add-loan-application.component';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule, Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { NgModule, Injectable } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoanApplicationComponent } from './loan-application.component';
import { LoanScheduleComponent } from './loan-schedule/loan-schedule.component';
import { CustomerService } from 'src/app/service/customer.service';
import { LoanDetailComponent } from './loan-detail/loan-detail.component';


@Injectable()
export class customerObjReolver implements  Resolve<any>{
  constructor(private service:CustomerService) {}
    resolve(route:ActivatedRouteSnapshot){
    const id = route.params['id'];
      return this.service.getCustomerByNumber(id);
    }

  }


@Injectable()
export class loanDetailResolver implements  Resolve<any>{
  constructor(private service:LoanApplicationService) {}
    resolve(route:ActivatedRouteSnapshot){
    const id = route.params['id'];
      return this.service.getLoanDetail(id);
    }

  }

export const loanapplicationRoutes:Routes=[
  {
    path:'',
  component:LoanApplicationComponent
},{
  path:'add',
 component: AddLoanApplicationComponent
},
  {
    path:'schedule',
    component: LoanScheduleComponent
  },
  {
    path:'create-loan/:id',
    component:AddLoanApplicationComponent,
    resolve:{
      customer:customerObjReolver
    }
  },
  {
    path:':id',
    component:LoanApplicationComponent,
    resolve:{
      customer:customerObjReolver
    }
  },
  {
    path:'detail/:id',
    component:LoanDetailComponent,
    resolve:{
      loan:loanDetailResolver
    }
  }


]
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(loanapplicationRoutes)
  ],
  declarations: [LoanApplicationComponent,AddLoanApplicationComponent, LoanScheduleComponent,LoanDetailComponent],
  providers:[LoanApplicationService,customerObjReolver,loanDetailResolver]
})
export class LoanApplicationModule { }
