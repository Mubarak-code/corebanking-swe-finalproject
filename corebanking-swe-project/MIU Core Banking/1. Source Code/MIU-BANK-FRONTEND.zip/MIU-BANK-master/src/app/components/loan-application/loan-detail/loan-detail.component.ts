import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-detail',
  templateUrl: './loan-detail.component.html',
  styleUrls: ['./loan-detail.component.css']
})
export class LoanDetailComponent implements OnInit {
  loanDetail: any;
  schedules: any;

  constructor(private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.data.subscribe(res => {
      this.schedules = res.loan.data;
      console.log(res)
    })
  }

}
