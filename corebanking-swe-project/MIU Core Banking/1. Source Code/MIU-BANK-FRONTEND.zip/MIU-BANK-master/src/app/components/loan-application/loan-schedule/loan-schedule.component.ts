import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-schedule',
  templateUrl: './loan-schedule.component.html',
  styleUrls: ['./loan-schedule.component.css']
})
export class LoanScheduleComponent implements OnInit {

  loanSchedule: any[];

  constructor() { }

  ngOnInit(): void {
  }

}
