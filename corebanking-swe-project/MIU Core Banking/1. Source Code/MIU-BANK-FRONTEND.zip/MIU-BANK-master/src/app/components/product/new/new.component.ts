import { ProductService } from '../../../service/product.service';
import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  supplier:any={};
  @Input() bankName: string;
  constructor(private productService:ProductService, private router: Router,private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.data.subscribe(res =>{
      if(res.product){
        this.supplier = res.product
      }
    })
  }

  createSupplier(){
    this.productService.createProduct(this.supplier).subscribe(res =>{
      this.navigateToLIst();});
  }

  navigateToLIst() {
      this.router.navigate(['/product']);
  }

}
