import { Supplier } from './../../model/supplier.model';
import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../service/product.service';
import { Router } from '@angular/router';
import {ISupplier} from '../../model/ISupplier'
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  suppliers:Supplier[];
  supler:ISupplier={};
  constructor(private productService:ProductService, private router: Router) { }

  ngOnInit() {

    this.productService.getAll().subscribe(res => {

      this.suppliers = res;
      console.log("this.suppliers",   this.suppliers )
    });
  }
  navigateToEdit(id: any) {
    if (id) {
      this.router.navigate(['/product', id, 'edit']);
    }
  }

  handle(){
    console.log("fasdf",this.supler)

  }
}
