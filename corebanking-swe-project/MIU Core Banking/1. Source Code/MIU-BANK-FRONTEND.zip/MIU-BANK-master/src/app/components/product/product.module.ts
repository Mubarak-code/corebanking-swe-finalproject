import { ProductService } from '../../service/product.service';
import { NewComponent } from './new/new.component';
import { NgModule, Injectable } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductComponent } from './product.component';
import { Routes, RouterModule, Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Injectable()
export class productResolver implements Resolve<any>{
  constructor(private service: ProductService) { }
  resolve(route: ActivatedRouteSnapshot) {
    const id = route.params['id'] ? route.params['id'] : null;
    console.log('iddd',id)
    if (id) {
      return this.service.getProductById(id);
    }
  }
}

export const productRoutes: Routes = [
  {
    path: '',
    component: ProductComponent,
  },
  {
    path: 'new',
    component: NewComponent,
  },
  {
    path: ':id/edit',
    component: NewComponent,
    resolve:{
      product:productResolver
    }
  }

]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(productRoutes),
    FormsModule
  ],
  declarations: [ProductComponent,NewComponent],
  providers:[productResolver]
})
export class ProductModule { }
