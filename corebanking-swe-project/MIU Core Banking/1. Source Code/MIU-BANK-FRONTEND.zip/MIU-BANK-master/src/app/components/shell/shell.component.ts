import { Customer } from './../../model/Customer';
import { Router } from '@angular/router';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserAccountService } from 'src/app/service/userAccount.service';

@Component({
  selector: 'app-shell',
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.css',
 //'./images/icons/favicon.ico',
'./fonts/font-awesome-4.7.0/css/font-awesome.min.css',
'./fonts/iconic/css/material-design-iconic-font.min.css',
'./vendor/animate/animate.css',
'./vendor/css-hamburgers/hamburgers.min.css',
'./vendor/animsition/css/animsition.min.css',
'./vendor/select2/select2.min.css',
'./vendor/daterangepicker/daterangepicker.css',
'./css/util.css',
 './css/main.css'
],
})
export class ShellComponent implements OnInit {

  user:any={};
  constructor(private userAccountService:UserAccountService,private route:Router) { }

  ngOnInit() {
  }

  login(){
    this.userAccountService.login(this.user).subscribe(res =>{
      if(res.data){
        localStorage.setItem('user', JSON.stringify(res.data[0]));
        localStorage.setItem('customer', JSON.stringify(res.data[0].customer));
        this.route.navigate(['dashboard'])
        JSON.parse(localStorage.getItem("customer"));
        console.log("fsa", JSON.parse(localStorage.getItem("customer")))
      }else{
        alert("Login Error");
      }

    },err => {

    })
    // [routerLink]="['/dashboard']"

  }
  getUrl()
  {
    return "url('./images/mah1.jpg')";
  }
}
