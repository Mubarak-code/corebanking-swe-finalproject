import { Component, OnInit } from '@angular/core';
import {CustomerService} from "../../../service/customer.service";
import {FormBuilder} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {TransactionService} from "../../../service/transaction.service";
import {Account} from "../../../model/Account";

@Component({
  selector: 'app-account-list',
  templateUrl: './account-list.component.html',
  styleUrls: ['./account-list.component.css']
})
export class AccountListComponent implements OnInit {


  accountList: Account[];
  user: any={};
  customerNumber: any;
  // accountListLength: number;

  constructor(private customerService: CustomerService,private formBuilder: FormBuilder, private router: Router,
              private route:ActivatedRoute, private transactionService: TransactionService) { }

  ngOnInit(): void {
    this.user =  JSON.parse(localStorage.getItem("user"));
    console.log(this.user);
    this.customerNumber = this.user.customer.customerNumber;
    this.getAccounts();
    // this.accountListLength = this.accountList.length;
  }

  getAccounts(){
    this.transactionService.getAccountByCustomerNumber(this.customerNumber).subscribe(
      res=>{
        this.accountList = res.data;
      }
    )
  }

  navigateToTransaction(id: string, transactionType: string) {
    if (id) {
      this.router.navigate(['student/make-transaction',id, transactionType])
    }
  }

}
