import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {CustomerService} from "../../../service/customer.service";
import {ActivatedRoute, Router} from "@angular/router";
import {TransactionService} from "../../../service/transaction.service";

@Component({
  selector: 'app-make-transaction',
  templateUrl: './make-transaction.component.html',
  styleUrls: ['./make-transaction.component.css']
})
export class MakeTransactionComponent implements OnInit {

  transactionType:string;
  private customerId:number;
  transactionForm: FormGroup;
  toAccountId:number;
  fromAccountId:number;
  allUtility: any[];
  accountNumber:number;
  constructor(private customerService: CustomerService, private formBuilder: FormBuilder, private router: Router,
              private route:ActivatedRoute, private transactionService: TransactionService) { }

  ngOnInit(): void {
    this.route.data.subscribe(res => {
      console.log("res",res);
      // @ts-ignore
      this.transactionType = this.route.params.value.transactionType;
      // this.customerId= res.customer.data[0].customerId;
      this.fromAccountId= res.customer.data[0].accountId;
    });
    this.transactionForm = this.formBuilder.group({
        transfer: this.formBuilder.group({
        fromAccountId: [this.fromAccountId, Validators.required],
          toAccountId : [this.toAccountId, Validators.required],
        amount: [0, Validators.required],
        description: ['', Validators.required]
      }),
      utility: this.formBuilder.group({
        fromAccountId: [this.fromAccountId, Validators.required],
        toAccountId : ['', Validators.required],
        amount: [0, Validators.required],
        description: ['', Validators.required]
      })
    });
    this.getUtility();
  }
  utility(){
    this.transactionService.getAccountByAccountNumber(this.accountNumber).subscribe(

      res=>{
        // this.transactionForm.value.utility.toAccountId =  res.data[0].accountId
        // this.toAccountId = this.accountNumber;
        this.transactionService.payUtility(this.transactionForm.value.utility).subscribe(
          res=>{
            console.log("as",this.transactionForm.value.transfer);
            this.transactionForm.reset();
            this.router.navigate(['/dashboard'])
          }
        )
      }

    );
    // this.transactionService.transfer(this.transactionForm.value.transfer).subscribe(
    //   res=>{
    //     console.log("as",this.transactionForm.value.transfer)
    //     this.transactionForm.reset();
    //     this.router.navigate(['/dashboard'])
    //   }
    // )
  }

  transfer(){
    this.transactionService.getAccountByAccountNumber(this.accountNumber).subscribe(

      res=>{
        console.log()
        this.transactionForm.value.transfer.toAccountId =  res.data[0].accountId
        // this.toAccountId = this.accountNumber;
        this.transactionService.transfer(this.transactionForm.value.transfer).subscribe(
          res=>{
            console.log("as",this.transactionForm.value.transfer);
            this.transactionForm.reset();
            this.router.navigate(['/dashboard'])
          }
        )
      }

    );
  }

  getUtility(){
    this.transactionService.getAllUtility().subscribe(
      res=>{
        this.allUtility = res.data;
      }
    )
  }

}
