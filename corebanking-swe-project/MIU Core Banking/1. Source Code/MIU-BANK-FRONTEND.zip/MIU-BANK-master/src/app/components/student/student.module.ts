import {Injectable, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentComponent } from './student.component';
import {Routes, RouterModule, Resolve, ActivatedRouteSnapshot} from '@angular/router';
import { AccountListComponent } from './account-list/account-list.component';
import { MakeTransactionComponent } from './make-transaction/make-transaction.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {CustomerService} from "../../service/customer.service";
import {customerResolver} from "../teller/teller.module";
import {TransactionService} from "../../service/transaction.service";
import {SendPaycheckComponent} from "../teller/send-paycheck/send-paycheck.component";

@Injectable()
export class accountResolver implements  Resolve<any>{
  constructor(private service:TransactionService) {}
  resolve(route:ActivatedRouteSnapshot){
    const id = route.params['id'];
    const transactionType = route.params['transactionType'];
    return this.service.getAccountByAccountNumber(id);
  }

}

export const studentRoutes: Routes = [
  {
    path: 'account-list',
    component: AccountListComponent,

  },
  {
    path:'make-transaction/:id/:transactionType',
    component: MakeTransactionComponent,
    resolve:{
      customer:accountResolver
    }
  }

];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(studentRoutes),
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [StudentComponent, AccountListComponent, MakeTransactionComponent],
  providers:[
    accountResolver
  ]
})
export class StudentModule { }
