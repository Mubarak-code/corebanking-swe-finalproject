import { Component, OnInit } from '@angular/core';
import {CustomerService} from "../../../service/customer.service";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, ActivatedRouteSnapshot, Router} from "@angular/router";
import {AccountType} from "../../../model/AccountType";

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  accountForm: FormGroup;
  accountType: AccountType[];
  private customerId:number;
  account: any;
  customerTypeId: any;
  constructor(private customerService: CustomerService, private formBuilder: FormBuilder, private router: Router,
              private route:ActivatedRoute) { }

  ngOnInit(): void {
    // console.log("rooute",this.route.params.value.id)
    this.route.data.subscribe(res => {
     this.customerId= res.customer.data[0].customerId;
     this.customerTypeId = res.customer.data[0].customerTypeId;

    });
    this.accountForm =this.formBuilder.group({
      account:this.formBuilder.group({
        // accountNumber: ['', Validators.required],
        balance: ['', Validators.required],
        accountTypeId: [null, Validators.required],
        customerId: [this.customerId, Validators.required]
      })
    });
    this.getAccountType();
  }

  createAccount(){
    this.customerService.createAccount(this.accountForm.value.account).subscribe(
      res=>{
        alert("Operation Successfull!");
        this.accountForm.reset();
        this.router.navigate(['/teller/list-customer']);
      }
    )
  }

  getAccountType(){
    this.customerService.getAccountType().subscribe(
      res=>{
        console.log("this.accountType",res.data)
        this.accountType =
        res.data.slice(0,2)

        if(this.customerTypeId = 2){

        }
      }
    )
  }

}
