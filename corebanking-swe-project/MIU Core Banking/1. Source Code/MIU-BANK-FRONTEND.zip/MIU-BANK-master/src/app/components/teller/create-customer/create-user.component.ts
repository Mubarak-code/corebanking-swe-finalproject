import { Component, OnInit } from '@angular/core';
import {CustomerService} from "../../../service/customer.service";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {CustomerType} from "../../../model/CustomerType";

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  customerForm: FormGroup;
  customerType: CustomerType[];

  constructor(private customerService: CustomerService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.customerForm =this.formBuilder.group({
      customer:this.formBuilder.group({
        customerName: ['', Validators.required],
        customerNumber: ['', Validators.required],
        contactPhone: ['', Validators.required],
        state: ['', Validators.required],
        city: ['', Validators.required],
        street: ['', Validators.required],
        zipcode: ['', Validators.required],
        apartmentNumber: ['', Validators.required],
        customerType: [null, Validators.required]

      })
    });
    this.getCustomerType();
  }


  createCustomer(){
    // alert(JSON.stringify(this.customerForm.value));
    // debugger;
    this.customerService.createCustomer(this.customerForm.value.customer).subscribe(
      res=>{
        alert("Operation Successfull!");
        this.customerForm.reset();
        this.router.navigate(['/teller/list-customer']);
      }
    )
  }

  getCustomerType(){
    this.customerService.getCustomerType().subscribe(
      res=>{
        this.customerType = res.data;
      }
    )
  }

}
