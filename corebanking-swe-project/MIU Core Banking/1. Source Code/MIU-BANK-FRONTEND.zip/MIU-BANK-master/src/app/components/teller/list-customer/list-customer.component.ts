import { Component, OnInit } from '@angular/core';
import {Routes, RouterModule, Router} from '@angular/router';
import {Customer} from "../../../model/Customer";
import {CustomerService} from "../../../service/customer.service";

@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css']
})
export class ListCustomerComponent implements OnInit {

  listOfCustomers: Customer[];
  customerLength: number;

  constructor(private customerService: CustomerService, private router: Router) {
  }

  ngOnInit(): void {
    this.listAllCustomers();
  }

  listAllCustomers() {
    this.customerService.listCustomers().subscribe(
      res => {
        this.listOfCustomers = res.data;
        this.customerLength = res.data.length;

      }
    )
  }

  navigatetoAccount(id: string) {
    if (id) {
      this.router.navigate(['teller/create-account',id])
    }
  }

  navigateToPaycheck(id: string) {
    if (id) {
      this.router.navigate(['teller/send-paycheck',id])
    }
  }

  navigateToTransaction(id: string, transactionType: string) {
    if (id) {
      this.router.navigate(['teller/make-transaction',id, transactionType])
    }
  }
}
