import { Component, OnInit } from '@angular/core';
import {CustomerService} from "../../../service/customer.service";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {TransactionService} from "../../../service/transaction.service";

@Component({
  selector: 'app-make-transaction',
  templateUrl: './make-transaction.component.html',
  styleUrls: ['./make-transaction.component.css']
})
export class MakeTransactionComponent implements OnInit {

  transactionType:string;
  private customerId:number;
  transactionForm: FormGroup;
  accountId:number;

  constructor(private customerService: CustomerService, private formBuilder: FormBuilder, private router: Router,
              private route:ActivatedRoute, private transactionService: TransactionService) { }

  ngOnInit(): void {
    this.route.data.subscribe(res => {
      // console.log("res",res)
      // @ts-ignore
      this.transactionType = this.route.params.value.transactionType;
      this.customerId= res.customer.data[0].customerId;
      this.accountId= res.customer.data[0].account[0].accountId;
    });
    this.transactionForm = this.formBuilder.group({
      deposit: this.formBuilder.group({
        accountId: [this.accountId, Validators.required],
        amount: [0, Validators.required],
        description: ['', Validators.required]
      }),
      withdraw: this.formBuilder.group({
        accountId: [this.accountId, Validators.required],
        amount: [0, Validators.required],
        description: ['', Validators.required]
      }),
      transfer: this.formBuilder.group({
        fromAccountId: [this.accountId, Validators.required],
        amount: [0, Validators.required],
        description: ['', Validators.required]
      })
    });
  }

  deposit(){
    this.transactionService.deposit(this.transactionForm.value.deposit).subscribe(
      res=>{
        alert("Operation Successfull!");
        this.transactionForm.reset();
        this.router.navigate(['/dashboard'])
      }
    )
  }
  withdraw(){
    this.transactionService.withdraw(this.transactionForm.value.withdraw).subscribe(
      res=>{
        alert("Operation Successfull!");
        this.transactionForm.reset();
        this.router.navigate(['/dashboard'])
      }
    )
  }
}
