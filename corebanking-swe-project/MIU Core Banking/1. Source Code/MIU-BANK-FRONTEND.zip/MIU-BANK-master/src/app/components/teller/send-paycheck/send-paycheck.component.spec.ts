import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendPaycheckComponent } from './send-paycheck.component';

describe('SendPaycheckComponent', () => {
  let component: SendPaycheckComponent;
  let fixture: ComponentFixture<SendPaycheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendPaycheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendPaycheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
