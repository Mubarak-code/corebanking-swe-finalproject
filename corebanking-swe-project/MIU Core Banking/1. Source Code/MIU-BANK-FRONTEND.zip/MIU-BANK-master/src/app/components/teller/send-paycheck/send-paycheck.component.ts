import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {TransactionService} from "../../../service/transaction.service";
import {CustomerService} from "../../../service/customer.service";
import {FormArray, FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Account} from "../../../model/Account";

@Component({
  selector: 'app-send-paycheck',
  templateUrl: './send-paycheck.component.html',
  styleUrls: ['./send-paycheck.component.css']
})
export class SendPaycheckComponent implements OnInit {

  private customerNumber:number;
  paycheckForm: FormGroup;
  accountList: Account[];
  fromAccountId:number;
  constructor(private customerService: CustomerService, private formBuilder: FormBuilder, private router: Router,
              private route:ActivatedRoute, private paycheckService: TransactionService) { }

  ngOnInit(): void {
    this.route.data.subscribe(res => {
      console.log("customer",res.customer.data);
      this.customerNumber= res.customer.data[0].customerNumber;
      this.fromAccountId= res.customer.data[0].account[0].accountId;
      this.getAccountByCustomerNumber();
    });

    this.paycheckForm = this.formBuilder.group({
      paycheck: this.formBuilder.group({
        accountId:['', Validators.required],
        amount:['', Validators.required],
        paycheckdetail:this.formBuilder.array([])
        // paycheckdetail: this.formBuilder.array({
        //   amount:['',Validators.required],
        //   accountId:['', Validators.required]
        // })
      })
    })
  }

  sendPaycheck(){
    let paymentdetail:any=[
      {amount:0,accountId:0}
    ];
    paymentdetail.forEach(e =>{
      e.amount = this.paycheckForm.value.paycheck.amount;
        e.accountId = this.paycheckForm.value.paycheck.accountId
    });
    this.paycheckForm.value.paycheck.accountId = 1;
    this.paycheckForm.value.paycheck.paycheckdetail =paymentdetail;
    this.paycheckService.sendPaycheck(this.paycheckForm.value.paycheck).subscribe(
      res=>{
        alert("Operation Successfull!");
        this.paycheckForm.reset();
        this.router.navigate(['/teller/list-customer']);
      }
    )
  }

  getAccountByCustomerNumber(){
    this.paycheckService.getAccountByCustomerNumber(this.customerNumber).subscribe(
      res=>{
        this.accountList = res.data;
      }
    )
  }

}
