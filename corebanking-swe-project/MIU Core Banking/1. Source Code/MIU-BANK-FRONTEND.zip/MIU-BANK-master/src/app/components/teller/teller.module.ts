import {Injectable, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import {Routes, RouterModule, ActivatedRouteSnapshot, Resolve} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { TellerComponent } from './teller.component';
import {CreateUserComponent} from "./create-customer/create-user.component";
import {ListCustomerComponent} from "./list-customer/list-customer.component";
import {SendPaycheckComponent} from "./send-paycheck/send-paycheck.component";
import {transactionRoutes} from "../Transaction/Transaction.module";
import { CreateAccountComponent } from './create-account/create-account.component';
import {CustomerService} from "../../service/customer.service";
import { TransactionComponent } from './transaction/transaction.component';
import { MakeTransactionComponent } from './make-transaction/make-transaction.component';
@Injectable()
export class customerResolver implements  Resolve<any>{
  constructor(private service:CustomerService) {}
    resolve(route:ActivatedRouteSnapshot){
    const id = route.params['id'];
    const transactionType = route.params['transactionType'];
      return this.service.getCustomerByNumber(id);
    }

  }

export const tellerRoute:Routes =[
  {
    path:'list-customer',
    component: ListCustomerComponent
  },
  {
    path:'transaction',
    component: TransactionComponent
  },
  {
    path:'send-paycheck/:id',
    component: SendPaycheckComponent,
    resolve:{
      customer:customerResolver
    }
  },
  {
    path:'make-transaction/:id/:transactionType',
    component: MakeTransactionComponent,
    resolve:{
      customer:customerResolver
    }
  },
  {
    path: 'create-customer',
    component: CreateUserComponent
  },
  {
    path:'create-account/:id',
    component:CreateAccountComponent,
    resolve:{
      customer:customerResolver
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(tellerRoute),
    ReactiveFormsModule,
  ],
  declarations: [TellerComponent, CreateUserComponent, ListCustomerComponent, SendPaycheckComponent, CreateAccountComponent, TransactionComponent, MakeTransactionComponent],
  providers:[
    customerResolver
  ]
})
export class TellerModule { }
