import { Component, OnInit } from '@angular/core';
import {CustomerService} from "../../../service/customer.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Customer} from "../../../model/Customer";
import {TransactionService} from "../../../service/transaction.service";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  listOfCustomers: Customer[];
  customerLength: number;
  transactionForm: FormGroup;

  constructor(private customerService: CustomerService,private formBuilder: FormBuilder, private router: Router,
  private route:ActivatedRoute, private transactionService: TransactionService) { }

  ngOnInit(): void {
    // this.transactionForm = this.formBuilder.group({
    //   deposit: this.formBuilder.group({
    //     accountId: ['', Validators.required],
    //     amount: ['', Validators.required],
    //     description: ['', Validators.required]
    //   }),
    //   withdraw: this.formBuilder.group({
    //     accountId: ['', Validators.required],
    //     amount: ['', Validators.required],
    //     description: ['', Validators.required]
    //   })
    // });
    this.listAllCustomers();
  }

  listAllCustomers() {
    this.customerService.listCustomers().subscribe(
      res => {
        this.listOfCustomers = res.data;
        this.customerLength = res.data.length;
      }
    )
  }
  // deposit(body){
  //   this.transactionService.deposit(this.transactionForm.value.deposit).subscribe(
  //     res=>{
  //       this.transactionForm.reset();
  //       this.router.navigate(['/teller/transaction'])
  //     }
  //   )
  // }
  // withdraw(body){
  //   this.transactionService.withdraw(this.transactionForm.value.withdraw).subscribe(
  //     res=>{
  //       this.transactionForm.reset();
  //       this.router.navigate(['/teller/transaction'])
  //     }
  //   )
  // }
  navigateToTransaction(id: string, transactionType: string) {
    if (id) {
      this.router.navigate(['teller/make-transaction',id, transactionType])
    }
  }
}
