import { CustomerService } from 'src/app/service/customer.service';
import { Component, OnInit } from '@angular/core';
import { UserAccountService } from 'src/app/service/userAccount.service';

@Component({
  selector: 'app-user-account',
  templateUrl: './user-account.component.html',
  styleUrls: ['./user-account.component.css',

  './fonts/font-awesome-4.7.0/css/font-awesome.min.css',
  './fonts/iconic/css/material-design-iconic-font.min.css',
  './vendor/animate/animate.css',
  './vendor/css-hamburgers/hamburgers.min.css',
  './vendor/animsition/css/animsition.min.css',
  './vendor/select2/select2.min.css',
  './vendor/daterangepicker/daterangepicker.css',
  './css/util.css',
   './css/main.css']
})
export class UserAccountComponent implements OnInit {
  isExist:boolean;
  accountNumber:any;
  customer: any={};
  userAccount:any={};
  userTypes: any;
  constructor(private customerService: CustomerService,private userAccountService :UserAccountService) { }

  ngOnInit() {
    this.userAccountService.userType().subscribe(res => {
      this.userTypes = res.data;
      console.log("this.userTypes[3];",this.userTypes)
    })
  }

  check(){
    this.customerService.getCustomerByNumber(this.accountNumber).subscribe(res => {
      if(res.data[0].customerId){
        console.log(res.data)
        this.customer = res.data[0];
        this.userAccount.customer = this.customer;
        this.isExist= true;
      }else{
        this.isExist= false;
      }

    })

  }

  creaUser(){
    this.userAccount.userType =this.userTypes[2];
    this.userAccountService.creaUserAccount(this.userAccount).subscribe(res => {
      alert("User Has been Created")
     this.previousState();
    })
  }

  previousState() {
    window.history.back();
  }
}
