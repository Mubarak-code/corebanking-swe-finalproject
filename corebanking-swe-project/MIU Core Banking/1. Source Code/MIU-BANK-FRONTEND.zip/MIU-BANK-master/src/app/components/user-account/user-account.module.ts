import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserAccountComponent } from './user-account.component';
import { Routes } from '@angular/router';


export const userAccountRoute:Routes =[
  {
    path:'',
    component:UserAccountComponent
  }
]

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(userAccountRoute)
  ],
  declarations: [UserAccountComponent]
})
export class UserAccountModule { }
