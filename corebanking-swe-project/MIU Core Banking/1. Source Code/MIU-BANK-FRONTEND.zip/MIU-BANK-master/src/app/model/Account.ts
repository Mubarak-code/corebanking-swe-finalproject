import {Customer} from "./Customer";
import {AccountType} from "./AccountType";

export class Account {
  accountId: number;
  accountNumber: string;
  balance: number;
  active: boolean;
  accountType: AccountType;
  customer: Customer;
}
