export class AccountType {
  accountTypeId: number;
  accountTypeName: string;
}
