import {Account} from "./Account";
import {CustomerType} from "./CustomerType";

export class Customer {
  customerId: number;
  customerName: string;
  customerNumber: string;
  contactPhone: string;
  state: string;
  city: string;
  street: string;
  zipcode: string;
  apartmentNumber: string;
  customerType: CustomerType;
  account: Account;
}
