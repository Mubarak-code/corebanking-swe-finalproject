export class CustomerType {
  customerTypeId: number;
  customerTypeName: string;
}
