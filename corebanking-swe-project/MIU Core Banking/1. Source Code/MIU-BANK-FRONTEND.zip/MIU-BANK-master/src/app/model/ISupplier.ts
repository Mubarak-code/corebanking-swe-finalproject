export interface ISupplier {
  supplierId?: number;
  name1?:string;
  contactPhoneNumber?:string;
}
