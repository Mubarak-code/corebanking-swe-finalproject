import { Deserializable } from './Deserializable';


export class Supplier implements Deserializable  {
  private _supplierId: number;


  private _spNum: number;

  private _name1: string;

  private _contactPhoneNumber: string;

  products:[];
  deserialize(input: any): this {
    Object.assign(this, input);
    return this;
  }

  public set contactPhoneNumber(value: string) {
    this._contactPhoneNumber = value;
  }

  public getname(): string {
    return this._name1;
  }

  public set name1(value: string) {
    this._name1 = value;
  }

  public getcontactPhoneNumber(): string {
    return this._contactPhoneNumber;
  }

  public get supplierId(): number {
    return this._supplierId;
  }

  public set supplierId(value: number) {
    this._supplierId = value;
  }

  public get spNum(): number {
    return this._spNum;
  }

  public set spNum(value: number) {
    this._spNum = value;
  }
}
