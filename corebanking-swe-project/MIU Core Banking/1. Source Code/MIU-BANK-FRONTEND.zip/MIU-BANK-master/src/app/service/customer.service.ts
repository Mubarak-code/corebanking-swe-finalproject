import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {map, tap} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private customerApi: String = 'http://localhost:8081/api';

  constructor(private httpClient: HttpClient) { }

  createCustomer(body): Observable<any>{
    return this.httpClient
      .post(this.customerApi+'/createcustomer', body);
  }
  listCustomers(): Observable<any>{
    return this.httpClient
      .get(this.customerApi+'/getallcustomers');
  }
  getCustomerType(): Observable<any>{
    return this.httpClient
      .get(this.customerApi+'/getcustomertype');
  }
  getAccountType(): Observable<any>{
    return this.httpClient
      .get(this.customerApi+'/getaccounttype');
}
  createAccount(body): Observable<any>{
    return this.httpClient
      .post('http://localhost:8081/api/createaccount', body);
  }
  getCustomerByNumber(body): Observable<any>{
    return this.httpClient
      .get('http://localhost:8081/api/getcustomerbynumber/'+body );
  }

}
