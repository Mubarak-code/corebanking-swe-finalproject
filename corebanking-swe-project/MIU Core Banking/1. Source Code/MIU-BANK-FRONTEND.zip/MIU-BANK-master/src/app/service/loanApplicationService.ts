import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoanApplicationService {
  private customerApi: String = 'http://localhost:8081/api/';
constructor(private httpClient: HttpClient) { }

creatLoan(body): Observable<any>{
  return this.httpClient
    .post(this.customerApi +'createloanapp', body);
}

getLoanApplications(): Observable<any>{
  return this.httpClient
    .get(this.customerApi +'getallloanapplications');
}
getLoanApplicationsById(id): Observable<any>{
  return this.httpClient
    .get(this.customerApi +'getallloanapplications' + id);
}

  getLoanApplicationsByCustomerId(body): Observable<any>{
  return this.httpClient
    .get(this.customerApi+'getloanapplicationbycustomerid/'+body);
  }

getRates(): Observable<any>{
  return this.httpClient
    .get(this.customerApi +'getallrates');
}

getLoanDetail(id:any): Observable<any>{
  console.log("iiiiii",id)
  return this.httpClient
    .get(this.customerApi + 'getschedulesbyloanid/' +id);
}
}
