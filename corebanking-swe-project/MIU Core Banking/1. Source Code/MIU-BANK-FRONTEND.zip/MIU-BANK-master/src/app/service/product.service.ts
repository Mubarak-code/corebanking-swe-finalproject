import { Supplier } from './../model/supplier.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  baseUrl = 'http://localhost:8081/api';

  constructor(private http:HttpClient){}


  getAll(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/suppliers`).pipe(tap(x =>console.log(x)),map(x =>
       x.map((res:Supplier)=> new Supplier().deserialize(res))
    //  return y
    ));
}

createProduct(product:any): Observable<any> {
  return this.http.post(`${this.baseUrl}/suppliers/save`,product);
}

getProductById(id:any): Observable<any> {
  return this.http.get(`${this.baseUrl}/suppliers/${id}`);
}

}
