
import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class StudentService{

    baseUrl = 'http://localhost:8081/api';

    constructor(private http:HttpClient){}

    getAll(): Observable<any> {
        return this.http.get<any>(`${this.baseUrl}/students`);
    }
}
