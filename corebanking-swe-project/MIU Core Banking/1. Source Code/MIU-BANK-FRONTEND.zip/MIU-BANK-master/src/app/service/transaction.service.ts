import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private api: String = 'http://localhost:8081/api';
constructor(private httpClient: HttpClient) { }

payLoan(loanNumber): Observable<any>{
  return this.httpClient
    .post(`http://localhost:8081/api/loanpayment/`+loanNumber,null);
}
  sendPaycheck(body):Observable<any>{
    return this.httpClient
      .post(this.api+'/makepaycheck', body);
  }
  getAccountByCustomerNumber(body): Observable<any>{
    return this.httpClient
      .get(this.api+'/getaccountbycustomernumber/'+body );
  }
  getAccountByAccountNumber(body): Observable<any>{
  console.log("am here")
    return this.httpClient
      .get(this.api+'/getaccountbynumber/'+body );
  }
  deposit(body): Observable<any>{
    return this.httpClient
      .post(this.api+'/deposit' , body);
  }
  withdraw(body): Observable<any>{
    return this.httpClient
      .post(this.api+'/withdraw', body);
  }
  transfer(body): Observable<any>{
    return this.httpClient
      .post(this.api+'/transfer', body);
  }
  payUtility(body): Observable<any>{
  return this.httpClient
    .post(this.api + '/paymentutility', body);
  }
  getAllTransaction(): Observable<any>{
    return this.httpClient
      .get(this.api+'/getalltransactions');
  }
  getCustomerTransaction(body): Observable<any>{
    return this.httpClient
      .get(this.api+'/gettransactionbyaccountid/'+body);
  }
  getAllUtility():Observable<any>{
  return this.httpClient
    .get(this.api +'/getallutilitysettings');
  }
}
