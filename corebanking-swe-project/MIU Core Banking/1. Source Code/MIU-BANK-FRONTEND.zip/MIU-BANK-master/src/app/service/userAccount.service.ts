import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserAccountService {

  private customerApi: String = 'http://localhost:8081/api/';

constructor(private httpClient: HttpClient) { }

creaUserAccount(body): Observable<any>{
  return this.httpClient
    .post(this.customerApi +'createuser', body);
}
userType(): Observable<any>{
  return this.httpClient
    .get(this.customerApi +'getallusertypes');
}

login(body): Observable<any>{
  return this.httpClient
    .post(this.customerApi +'login', body);
}
}
